import Link from "next/link";
import {
  ArrowLeft,
  Boxes,
  CircleDollarSign,
  PackageCheck,
  Search,
  TriangleAlert,
} from "lucide-react";
import { createClient } from "@/lib/supabase/server";

type SearchParams = Promise<{
  search?: string;
  status?: string;
}>;

type StockBalance = {
  id: string;
  branch_id: string;
  product_id: string;
  quantity: number | string;
  average_cost: number | string;
  updated_at: string;
};

type Product = {
  id: string;
  code: string;
  name: string;
};

type Branch = {
  id: string;
  name: string;
};

export default async function InventoryPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const filters = await searchParams;
  const search = filters.search?.trim().toLowerCase() ?? "";
  const status = filters.status ?? "all";

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select("business_id")
    .eq("id", user!.id)
    .single();

  const businessId = profile?.business_id;

  const { data: stockData, error } = await supabase
    .from("stock_balances")
    .select(
      "id, branch_id, product_id, quantity, average_cost, updated_at"
    )
    .eq("business_id", businessId)
    .order("updated_at", { ascending: false });

  const stockBalances = (stockData ?? []) as StockBalance[];

  const productIds = [...new Set(stockBalances.map((item) => item.product_id))];
  const branchIds = [...new Set(stockBalances.map((item) => item.branch_id))];

  let products: Product[] = [];
  let branches: Branch[] = [];

  if (productIds.length > 0) {
    const { data } = await supabase
      .from("products")
      .select("id, code, name")
      .in("id", productIds);

    products = (data ?? []) as Product[];
  }

  if (branchIds.length > 0) {
    const { data } = await supabase
      .from("branches")
      .select("id, name")
      .in("id", branchIds);

    branches = (data ?? []) as Branch[];
  }

  const productMap = new Map(products.map((product) => [product.id, product]));
  const branchMap = new Map(branches.map((branch) => [branch.id, branch]));

  const inventory = stockBalances
    .map((item) => {
      const product = productMap.get(item.product_id);
      const branch = branchMap.get(item.branch_id);
      const quantity = Number(item.quantity ?? 0);
      const averageCost = Number(item.average_cost ?? 0);

      return {
        ...item,
        quantity,
        averageCost,
        stockValue: quantity * averageCost,
        productCode: product?.code ?? "—",
        productName: product?.name ?? "Unknown Product",
        branchName: branch?.name ?? "Unknown Branch",
      };
    })
    .filter((item) => {
      const matchesSearch =
        !search ||
        item.productCode.toLowerCase().includes(search) ||
        item.productName.toLowerCase().includes(search) ||
        item.branchName.toLowerCase().includes(search);

      const matchesStatus =
        status === "all" ||
        (status === "in_stock" && item.quantity > 5) ||
        (status === "low_stock" &&
          item.quantity > 0 &&
          item.quantity <= 5) ||
        (status === "out_of_stock" && item.quantity <= 0);

      return matchesSearch && matchesStatus;
    });

  const totalProducts = stockBalances.length;
  const inStock = stockBalances.filter(
    (item) => Number(item.quantity) > 0
  ).length;
  const lowStock = stockBalances.filter(
    (item) => Number(item.quantity) > 0 && Number(item.quantity) <= 5
  ).length;
  const totalValue = stockBalances.reduce(
    (sum, item) =>
      sum + Number(item.quantity ?? 0) * Number(item.average_cost ?? 0),
    0
  );

  const money = (value: number) =>
    new Intl.NumberFormat("en-LK", {
      style: "currency",
      currency: "LKR",
      minimumFractionDigits: 2,
    }).format(value);

  return (
    <main className="min-h-screen bg-slate-50 p-4 text-slate-900 sm:p-8">
      <div className="mx-auto max-w-7xl">
        <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <Link
              href="/"
              className="mb-4 inline-flex items-center gap-2 text-sm font-semibold text-blue-600 hover:text-blue-700"
            >
              <ArrowLeft size={18} />
              Back to Dashboard
            </Link>

            <h1 className="text-3xl font-bold">Inventory</h1>
            <p className="mt-2 text-slate-500">
              Monitor current stock quantities, costs and stock values.
            </p>
          </div>
         <div className="flex flex-col gap-3 sm:flex-row">
  <Link
    href="/inventory/movements"
    className="inline-flex h-12 items-center justify-center rounded-xl border border-slate-300 bg-white px-5 font-semibold text-slate-700 shadow-sm hover:bg-slate-50"
  >
    Stock Movement History
  </Link>

  <Link
    href="/inventory/adjustments/new"
    className="inline-flex h-12 items-center justify-center rounded-xl bg-blue-600 px-5 font-semibold text-white shadow-sm hover:bg-blue-700"
  >
    New Adjustment
  </Link>
</div>
        </header>

        <section className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <SummaryCard
            title="Stock Items"
            value={String(totalProducts)}
            icon={<Boxes size={24} />}
            color="text-slate-900"
            background="bg-slate-100"
          />

          <SummaryCard
            title="In Stock"
            value={String(inStock)}
            icon={<PackageCheck size={24} />}
            color="text-emerald-600"
            background="bg-emerald-50"
          />

          <SummaryCard
            title="Low Stock"
            value={String(lowStock)}
            icon={<TriangleAlert size={24} />}
            color="text-amber-600"
            background="bg-amber-50"
          />

          <SummaryCard
            title="Inventory Value"
            value={money(totalValue)}
            icon={<CircleDollarSign size={24} />}
            color="text-blue-600"
            background="bg-blue-50"
          />
        </section>

        <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="border-b border-slate-200 p-6">
            <h2 className="text-lg font-bold">Current Stock</h2>
            <p className="mt-1 text-sm text-slate-500">
              {inventory.length} stock item{inventory.length === 1 ? "" : "s"}{" "}
              found
            </p>
          </div>

          <form className="grid gap-3 border-b border-slate-200 bg-slate-50 p-5 md:grid-cols-[1fr_240px_auto_auto]">
            <div className="relative">
              <Search
                size={19}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                name="search"
                defaultValue={filters.search ?? ""}
                placeholder="Search product code, name or branch"
                className="h-14 w-full rounded-xl border border-slate-300 bg-white pl-12 pr-4 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
            </div>

            <select
              name="status"
              defaultValue={status}
              className="h-14 rounded-xl border border-slate-300 bg-white px-4 outline-none focus:border-blue-500"
            >
              <option value="all">All stock statuses</option>
              <option value="in_stock">In stock</option>
              <option value="low_stock">Low stock</option>
              <option value="out_of_stock">Out of stock</option>
            </select>

            <button
              type="submit"
              className="h-14 rounded-xl bg-blue-600 px-6 font-semibold text-white hover:bg-blue-700"
            >
              Apply
            </button>

            <Link
              href="/inventory"
              className="flex h-14 items-center justify-center rounded-xl border border-slate-300 bg-white px-6 font-semibold hover:bg-slate-50"
            >
              Clear
            </Link>
          </form>

          {error ? (
            <div className="p-10 text-center">
              <p className="font-semibold text-red-600">
                Inventory could not be loaded
              </p>
              <p className="mt-2 text-sm text-slate-500">{error.message}</p>
            </div>
          ) : inventory.length === 0 ? (
            <div className="flex min-h-72 flex-col items-center justify-center p-10 text-center">
              <Boxes size={54} className="text-slate-300" />
              <h3 className="mt-4 text-lg font-bold">No inventory found</h3>
              <p className="mt-2 text-slate-500">
                Stock will appear after receiving a purchase order.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[950px] text-left">
                <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                  <tr>
                    <th className="px-6 py-4">Product</th>
                    <th className="px-6 py-4">Branch</th>
                    <th className="px-6 py-4 text-right">Quantity</th>
                    <th className="px-6 py-4 text-right">Average Cost</th>
                    <th className="px-6 py-4 text-right">Stock Value</th>
                    <th className="px-6 py-4">Status</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {inventory.map((item) => {
                    const stockStatus =
                      item.quantity <= 0
                        ? "Out of Stock"
                        : item.quantity <= 5
                          ? "Low Stock"
                          : "In Stock";

                    const badgeStyle =
                      item.quantity <= 0
                        ? "bg-red-50 text-red-700"
                        : item.quantity <= 5
                          ? "bg-amber-50 text-amber-700"
                          : "bg-emerald-50 text-emerald-700";

                    return (
                      <tr key={item.id} className="hover:bg-slate-50">
                        <td className="px-6 py-4">
                          <p className="font-semibold">{item.productName}</p>
                          <p className="mt-1 text-sm text-slate-500">
                            {item.productCode}
                          </p>
                        </td>

                        <td className="px-6 py-4 text-slate-600">
                          {item.branchName}
                        </td>

                        <td className="px-6 py-4 text-right text-lg font-bold">
                          {item.quantity.toLocaleString()}
                        </td>

                        <td className="px-6 py-4 text-right">
                          {money(item.averageCost)}
                        </td>

                        <td className="px-6 py-4 text-right font-semibold">
                          {money(item.stockValue)}
                        </td>

                        <td className="px-6 py-4">
                          <span
                            className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${badgeStyle}`}
                          >
                            {stockStatus}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

function SummaryCard({
  title,
  value,
  icon,
  color,
  background,
}: {
  title: string;
  value: string;
  icon: React.ReactNode;
  color: string;
  background: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-center gap-4">
        <div
          className={`flex h-14 w-14 items-center justify-center rounded-xl ${background} ${color}`}
        >
          {icon}
        </div>

        <div className="min-w-0">
          <p className="text-sm text-slate-500">{title}</p>
          <p className={`mt-1 truncate text-2xl font-bold ${color}`}>{value}</p>
        </div>
      </div>
    </div>
  );
}